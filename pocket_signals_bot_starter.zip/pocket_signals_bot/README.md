# Pocket Signals — Telegram bot starter

This is a safe starter project for a Telegram bot that can later deliver market signals.
It does **not** generate fake CALL/PUT predictions. Until a verified, low-latency quote
provider is connected, `/signal` explains that no signal can be issued.

## 1. Create the Telegram bot

1. In Telegram, open the official `@BotFather`.
2. Send `/newbot` and follow the prompts.
3. Copy the bot token and keep it secret. Anyone with the token can control the bot.
4. Do not send the token to anyone or paste it into public chats.

## 2. Deploy 24/7 on Render

1. Create a private GitHub repository and upload these project files.
2. Create an account at Render and choose **New → Background Worker**.
3. Connect the repository. Render can read `render.yaml`; otherwise use:
   - Build command: `pip install -r requirements.txt`
   - Start command: `python main.py`
4. In the service's Environment settings, add:
   - `TELEGRAM_BOT_TOKEN` = your BotFather token
   - `BOT_TIMEZONE` = `Europe/Kyiv`
5. Deploy, then open your bot in Telegram and send `/start`.

Check Render's current pricing and free-tier limits before deploying; always-on workers
may require a paid plan depending on the current offering.

## 3. Try commands

- `/start`
- `/pairs`
- `/signal EURUSD 3`
- `/signal EURUSD_OTC 5`

## 4. Important: live signal feed is not configured yet

A useful 3- or 5-second CALL/PUT signal requires fresh tick data with accurate timestamps.
Ordinary forex data APIs may not provide the same prices as Pocket Option, and OTC prices
are platform-specific. Do not assume an external EUR/USD feed matches EUR/USD OTC.

Before enabling signals, implement a `MarketDataProvider` adapter that:
- obtains data from a permitted and reliable source;
- checks freshness and timestamps;
- refuses to issue signals when data is stale or missing;
- is validated against historical/demo observations;
- never opens trades automatically.

Do not automate Pocket Option login or share broker credentials with a third-party service.
This starter does not log in to Pocket Option or place trades.
