import os
import logging
from datetime import datetime
from zoneinfo import ZoneInfo

from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, ContextTypes

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("pocket-signals")

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TIMEZONE = os.getenv("BOT_TIMEZONE", "Europe/Kyiv").strip()

PAIRS = {
    "EURUSD": "EUR/USD",
    "GBPUSD": "GBP/USD",
    "USDJPY": "USD/JPY",
    "AUDUSD": "AUD/USD",
    "USDCAD": "USD/CAD",
    "EURJPY": "EUR/JPY",
    "GBPJPY": "GBP/JPY",
    "EURUSD_OTC": "EUR/USD OTC",
    "GBPUSD_OTC": "GBP/USD OTC",
    "USDJPY_OTC": "USD/JPY OTC",
}

HELP_TEXT = (
    "Pocket Signals — стартова версія\n\n"
    "Команди:\n"
    "/pairs — список підтримуваних пар\n"
    "/signal EURUSD 3 — запит сигналу з експірацією 3 секунди\n"
    "/signal EURUSD_OTC 5 — запит сигналу OTC з експірацією 5 секунд\n"
    "/help — допомога\n\n"
    "Важливо: джерело реальних котирувань ще не підключене. "
    "Тому бот НЕ вигадує CALL/PUT і не надсилає фальшиві сигнали."
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    keyboard = [["/pairs", "/help"], ["/signal EURUSD 3", "/signal EURUSD 5"]]
    await update.message.reply_text(
        "Привіт! Я Pocket Signals.\n\n" + HELP_TEXT,
        reply_markup=ReplyKeyboardMarkup(keyboard, resize_keyboard=True),
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(HELP_TEXT)

async def pairs_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    ordinary = [f"• {code} — {name}" for code, name in PAIRS.items() if not code.endswith("_OTC")]
    otc = [f"• {code} — {name}" for code, name in PAIRS.items() if code.endswith("_OTC")]
    await update.message.reply_text(
        "Звичайні пари:\n" + "\n".join(ordinary) +
        "\n\nOTC-пари (позначені як заплановані — потрібен окремий потік котирувань Pocket Option):\n" +
        "\n".join(otc)
    )

async def signal_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if len(context.args) != 2:
        await update.message.reply_text(
            "Формат: /signal EURUSD 3\n"
            "Пари: /pairs\n"
            "Експірація наразі підтримується як запит: 3 або 5 секунд."
        )
        return

    pair_code = context.args[0].upper()
    duration = context.args[1]

    if pair_code not in PAIRS:
        await update.message.reply_text("Не знаю таку пару. Напиши /pairs.")
        return
    if duration not in {"3", "5"}:
        await update.message.reply_text("Для цієї версії обери експірацію 3 або 5 секунд.")
        return

    pair_name = PAIRS[pair_code]
    now = datetime.now(ZoneInfo(TIMEZONE)).astimezone()
    timestamp = now.strftime("%Y-%m-%d %H:%M:%S %Z")

    # Deliberately do not invent CALL/PUT. A verified, low-latency market-data
    # adapter must be connected before a real signal can be issued.
    await update.message.reply_text(
        f"📊 Запит сигналу\n"
        f"Пара: {pair_name}\n"
        f"Експірація: {duration} сек.\n"
        f"Час запиту: {timestamp}\n\n"
        f"⚠️ Сигнал не сформовано: джерело актуальних котирувань не підключене.\n"
        f"Для реального CALL/PUT потрібні свіжі тики цієї пари. "
        f"Для OTC потрібен потік, що відповідає цінам Pocket Option. "
        f"Я не буду підставляти випадковий напрямок."
    )

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    log.exception("Telegram bot error", exc_info=context.error)

def main() -> None:
    if not BOT_TOKEN:
        raise RuntimeError(
            "Не задано TELEGRAM_BOT_TOKEN. Створи .env локально або додай змінну "
            "середовища на хостингу. Не публікуй токен."
        )
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("pairs", pairs_command))
    app.add_handler(CommandHandler("signal", signal_command))
    app.add_error_handler(error_handler)
    log.info("Bot starting; timezone=%s", TIMEZONE)
    app.run_polling()

if __name__ == "__main__":
    main()
