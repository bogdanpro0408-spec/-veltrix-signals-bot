import os
import sqlite3
import logging
from datetime import datetime, timedelta, timezone

from telegram import LabeledPrice, Update
from telegram.ext import (
    Application, CommandHandler, PreCheckoutQueryHandler,
    MessageHandler, ContextTypes, filters
)

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
OWNER_TELEGRAM_ID = int(os.getenv("OWNER_TELEGRAM_ID", "0") or "0")
PRICE_STARS = 100
ACCESS_HOURS = 24
TRIAL_HOURS = 24
DB_PATH = os.getenv("DB_PATH", "bot.sqlite3")
SIGNAL_FEED_ENABLED = os.getenv("SIGNAL_FEED_ENABLED", "false").lower() == "true"

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("pocket-signals")


def now_utc():
    return datetime.now(timezone.utc)


def parse_dt(value):
    return datetime.fromisoformat(value) if value else None


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                trial_started_at TEXT,
                access_until TEXT,
                terms_accepted INTEGER NOT NULL DEFAULT 0
            )
        """)
        con.execute("""
            CREATE TABLE IF NOT EXISTS payments (
                charge_id TEXT PRIMARY KEY,
                user_id INTEGER NOT NULL,
                amount INTEGER NOT NULL,
                currency TEXT NOT NULL,
                paid_at TEXT NOT NULL
            )
        """)


def get_user(user_id):
    with db() as con:
        row = con.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        if row:
            return dict(row)
        start = now_utc()
        con.execute(
            "INSERT INTO users(user_id, trial_started_at) VALUES (?, ?)",
            (user_id, start.isoformat()),
        )
        return {
            "user_id": user_id,
            "trial_started_at": start.isoformat(),
            "access_until": None,
            "terms_accepted": 0,
        }


def set_terms(user_id):
    with db() as con:
        con.execute("UPDATE users SET terms_accepted=1 WHERE user_id=?", (user_id,))


def has_access(user_id):
    if OWNER_TELEGRAM_ID and user_id == OWNER_TELEGRAM_ID:
        return True, "Власник: безкоштовний доступ."
    user = get_user(user_id)
    if not user["terms_accepted"]:
        return False, "Спочатку прийми умови командою /terms."
    access_until = parse_dt(user.get("access_until"))
    if access_until and access_until > now_utc():
        return True, f"Доступ активний до {access_until.astimezone().strftime('%Y-%m-%d %H:%M')}."
    trial_started = parse_dt(user.get("trial_started_at"))
    trial_until = trial_started + timedelta(hours=TRIAL_HOURS)
    if now_utc() < trial_until:
        return True, f"Пробний доступ активний до {trial_until.astimezone().strftime('%Y-%m-%d %H:%M')}."
    return False, "Пробний доступ завершився. Оплати 100 ⭐, щоб отримати ще 24 години."


TERMS_TEXT = (
    "Умови використання\\n\\n"
    "Бот надає інформаційні сигнали, а не фінансову пораду. Прибуток не гарантується; "
    "сигнали можуть бути неточними, а торгівля може призвести до втрати коштів. "
    "Перевіряй усе на деморахунку. Бот не відкриває угоди автоматично.\\n\\n"
    "Доступ: перші 24 години безкоштовно, потім 100 Telegram Stars за 24 години. "
    "Підтримка з оплат: команда /paysupport. Щоб продовжити, надішли /accept."
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    get_user(user.id)
    await update.message.reply_text(
        "Вітаю! Це бот сигналів Pocket Option.\\n"
        "• 24 години пробного доступу\\n"
        "• Потім 100 ⭐ за наступні 24 години\\n"
        "• Власник має безкоштовний доступ\\n\\n"
        "Перед початком переглянь /terms і надішли /accept.\\n"
        "Команди: /signal, /pairs, /buy, /status, /help"
    )


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "/terms — умови використання\\n"
        "/accept — прийняти умови\\n"
        "/status — стан доступу\\n"
        "/buy — оплатити 24 години за 100 ⭐\\n"
        "/pairs — перелік пар/формат команди\\n"
        "/signal EURUSD 1m — запросити сигнал (потрібне реальне джерело котирувань)\\n"
        "Час експірації: 3s, 5s, 1m, 2m, 3m, 5m."
    )


async def terms(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(TERMS_TEXT)


async def accept(update: Update, context: ContextTypes.DEFAULT_TYPE):
    get_user(update.effective_user.id)
    set_terms(update.effective_user.id)
    await update.message.reply_text(
        "Умови прийняті. Твій пробний доступ триває 24 години від першого запуску. "
        "Перевір /status."
    )


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ok, msg = has_access(update.effective_user.id)
    await update.message.reply_text(msg + ("" if ok else "\\nОплата: /buy"))


async def pairs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Пари залежать від джерела котирувань. Приклади форматів: EURUSD, GBPUSD, USDJPY, "
        "EURUSD_OTC. OTC потрібно отримувати саме з дозволеного джерела, сумісного з котируваннями "
        "Pocket Option. Джерело даних ще не підключено."
    )


async def buy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    get_user(user_id)
    if OWNER_TELEGRAM_ID and user_id == OWNER_TELEGRAM_ID:
        await update.message.reply_text("Ти власник — оплата не потрібна.")
        return
    if not get_user(user_id)["terms_accepted"]:
        await update.message.reply_text("Спочатку переглянь /terms і надішли /accept.")
        return
    await context.bot.send_invoice(
        chat_id=update.effective_chat.id,
        title="Доступ до сигналів на 24 години",
        description="24 години доступу до сигналів. Сигнали не гарантують прибутку.",
        payload=f"access24:{user_id}",
        provider_token="",
        currency="XTR",
        prices=[LabeledPrice("Доступ на 24 години", PRICE_STARS)],
    )


async def precheckout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.pre_checkout_query
    expected_payload = f"access24:{query.from_user.id}"
    if query.invoice_payload != expected_payload or query.currency != "XTR" or query.total_amount != PRICE_STARS:
        await query.answer(ok=False, error_message="Платіж не збігається з рахунком. Спробуй ще раз.")
        return
    await query.answer(ok=True)


async def successful_payment(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    payment = msg.successful_payment
    user_id = update.effective_user.id
    charge_id = payment.telegram_payment_charge_id
    if payment.currency != "XTR" or payment.total_amount != PRICE_STARS:
        await msg.reply_text("Платіж отримано, але параметри не збігаються. Напиши /paysupport.")
        return
    with db() as con:
        exists = con.execute("SELECT 1 FROM payments WHERE charge_id=?", (charge_id,)).fetchone()
        if exists:
            await msg.reply_text("Цей платіж уже був оброблений.")
            return
        user = con.execute("SELECT * FROM users WHERE user_id=?", (user_id,)).fetchone()
        current_until = parse_dt(user["access_until"]) if user and user["access_until"] else None
        start_at = max(now_utc(), current_until) if current_until else now_utc()
        new_until = start_at + timedelta(hours=ACCESS_HOURS)
        con.execute(
            "INSERT INTO payments(charge_id,user_id,amount,currency,paid_at) VALUES (?,?,?,?,?)",
            (charge_id, user_id, payment.total_amount, payment.currency, now_utc().isoformat()),
        )
        con.execute(
            "UPDATE users SET access_until=? WHERE user_id=?",
            (new_until.isoformat(), user_id),
        )
    await msg.reply_text(
        f"Оплату підтверджено! Доступ активний до {new_until.astimezone().strftime('%Y-%m-%d %H:%M')}."
    )


async def paysupport(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Підтримка щодо платежів: напиши власнику бота й надішли дату платежу та опис проблеми. "
        "Не надсилай паролі, коди входу або seed-фразу гаманця."
    )


async def signal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    ok, msg = has_access(update.effective_user.id)
    if not ok:
        await update.message.reply_text(msg + "\\nОплатити: /buy")
        return
    if not context.args or len(context.args) < 2:
        await update.message.reply_text(
            "Формат: /signal EURUSD 1m\\nДоступні експірації: 3s, 5s, 1m, 2m, 3m, 5m."
        )
        return
    pair = context.args[0].upper()
    expiry = context.args[1].lower()
    allowed = {"3s", "5s", "1m", "2m", "3m", "5m"}
    if expiry not in allowed:
        await update.message.reply_text("Невірна експірація. Обери: 3s, 5s, 1m, 2m, 3m або 5m.")
        return
    # Deliberately do not fabricate signals: a verified live quote/candle feed is not configured.
    if not SIGNAL_FEED_ENABLED:
        await update.message.reply_text(
            f"Пара: {pair}\\nЕкспірація: {expiry}\\n\\n"
            "Сигнал поки не сформовано: реальне джерело котирувань не підключене. "
            "Бот не вигадуватиме CALL/PUT без даних. OTC має надходити з дозволеного джерела, "
            "яке відповідає котируванням платформи."
        )
        return
    await update.message.reply_text(
        "Джерело даних позначене як увімкнене, але адаптер постачальника ще потрібно реалізувати "
        "та перевірити. Сигнал не сформовано."
    )


def main():
    if not BOT_TOKEN:
        raise RuntimeError("Вкажи BOT_TOKEN у змінних середовища.")
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_cmd))
    app.add_handler(CommandHandler("terms", terms))
    app.add_handler(CommandHandler("accept", accept))
    app.add_handler(CommandHandler("status", status))
    app.add_handler(CommandHandler("pairs", pairs))
    app.add_handler(CommandHandler("buy", buy))
    app.add_handler(CommandHandler("paysupport", paysupport))
    app.add_handler(CommandHandler("signal", signal))
    app.add_handler(PreCheckoutQueryHandler(precheckout))
    app.add_handler(MessageHandler(filters.SUCCESSFUL_PAYMENT, successful_payment))
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
