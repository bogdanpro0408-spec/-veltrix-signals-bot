# Pocket Signals Bot — starter v2

This project implements Telegram commands, a 24-hour trial, owner bypass, and Telegram Stars payment for 24-hour access at 100 Stars.

## Important limitations

- This is a starter project, not a fully operational signal service.
- No market quote/candle feed is connected. `/signal` intentionally refuses to invent CALL/PUT signals.
- A reliable FX feed must be chosen and licensed/authorized as appropriate.
- OTC prices are platform-specific; a generic FX provider may not match Pocket Option OTC quotes.
- 3–5 second expiry is extremely sensitive to latency and should not be treated as reliable without extensive demo testing.
- The SQLite database should be backed up. For production scale, use managed PostgreSQL and robust persistent hosting.
- Do not share your Pocket Option password, Telegram login code, bot token, wallet seed phrase, or private key.

## Configure

1. Create a bot using `@BotFather` and copy its token privately.
2. Find your numeric Telegram user ID using a reputable ID bot; do not share login codes.
3. Set environment variables:
   - `BOT_TOKEN`: BotFather token
   - `OWNER_TELEGRAM_ID`: your numeric Telegram user ID
   - `DB_PATH`: persistent database path
   - `SIGNAL_FEED_ENABLED=false` until a real data adapter has been implemented and tested
4. Install dependencies: `pip install -r requirements.txt`
5. Run: `python main.py`

## Commands

- `/start`
- `/terms`, then `/accept`
- `/status`
- `/buy` — invoice for 100 Telegram Stars, 24-hour access
- `/signal EURUSD 1m`
- `/pairs`
- `/paysupport`

## Payment notes

Digital access sold inside Telegram must be paid for using Telegram Stars (`XTR`). The bot checks the pre-checkout query and only extends access after `successful_payment`. Charge IDs are stored for basic duplicate-payment protection and potential refund handling.

## Signal feed

A live data adapter is intentionally not included. Add a provider only after confirming terms, availability, pair coverage, timestamp semantics, and whether OTC data is actually available. Do not enable `SIGNAL_FEED_ENABLED` as a shortcut: it does not create a feed or signals.
